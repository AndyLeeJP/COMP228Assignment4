package Lab4;



import javax.swing.*;

import java.awt.*;

import java.awt.event.*; // importing event package for event listener

class RegForm{

	
	static JTextField name_txt ;
	static JTextField address_txt;
	static JTextField province_txt;
	static JTextField city_txt;
	static JTextField postal_txt;
	static JRadioButton compu;
	static JRadioButton busine;
	static JComboBox cs;
	static JComboBox busi;
	static JTextField phone_txt;
	static JTextField email_txt;
	static JCheckBox chkbox1;
	static JCheckBox chkbox2;
	static JButton submit_btn;
	static JTextArea output_txtArea;
	
	public static void main(String args[])
	
	{
	
	
	JFrame frame=new JFrame("Register Form");  
	
	frame.setVisible(true);
	
	frame.setBounds(200,100,700,600 );   
	
	frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
	
	Container c=frame.getContentPane();
	
	c.setLayout(null);   
	
	JLabel name_lbl=new JLabel("Name : ");
	
	name_lbl.setBounds(50,80,50,30);
	
	name_txt=new JTextField();
	
	name_txt.setBounds(180,80,180,30);  
	
	JLabel address_lbl=new JLabel("Address: ");
	
	address_lbl.setBounds(50,120,150,30);  
	
	address_txt=new JTextField();
	
	address_txt.setBounds(180,120,180,30);
	
	JLabel province_lbl=new JLabel("Province: ");
	
	province_lbl.setBounds(50,160,150,30);  
	
	province_txt=new JTextField();
	
	province_txt.setBounds(180,160,180,30);
	
	JLabel city_lbl=new JLabel("City: ");
	
	city_lbl.setBounds(50,200,150,30);  
	
	city_txt=new JTextField();
	
	city_txt.setBounds(180,200,180,30);
	
	JLabel postal_lbl=new JLabel("Postal Code: ");
	
	postal_lbl.setBounds(50,240,150,30);  
	
	postal_txt=new JTextField();
	
	postal_txt.setBounds(180,240,180,30);
	
	JLabel phone_lbl=new JLabel("Phone Number : ");
	
	phone_lbl.setBounds(50,300,100,30);
	
	phone_txt=new JTextField();
	
	phone_txt.setBounds(180,300,180,30);
	
	
	JLabel email_lbl=new JLabel("Email Address: ");
	
	email_lbl.setBounds(50,340,100,30);
	
	
	email_txt=new JTextField();
	
	email_txt.setBounds(180,340,180,30);
	
	
	JLabel major_lbl=new JLabel();
						
						Cursor cur=new Cursor(Cursor.HAND_CURSOR);
			
						
						compu=new JRadioButton("Computer Science");
						
						compu.setBounds(100,400,150,30);
						
						compu.setCursor(cur);

						
						busine=new JRadioButton("Business");
						
						busine.setBounds(280,400,80,30);
						
						busine.setCursor(cur);

						
						ButtonGroup major_grp=new ButtonGroup();
						
						major_grp.add(compu); 
						
						major_grp.add(busine);
						
						JLabel sub_lbl=new JLabel("Subject : ");
						sub_lbl.setBounds(50,440,100,30);
						
						if(busine.isSelected()==true) {
							
							String busisub_arr[]={"Accounting","Math","Economy","Hospitality"};
							
							
							busi=new JComboBox(busisub_arr);
	
							busi.setBounds( 200, 440, 100, 30);
							
						}else {
						
							String cssub_arr[]={"Java","Python","C#","JavaScript","HTML&CSS"};
							
							
							cs=new JComboBox(cssub_arr);
	
							cs.setBounds(200,440,100,30);
						}
	
	
	chkbox1=new JCheckBox("Student Council");
	
	chkbox1.setBounds(50,500,300,30);
	
	chkbox2=new JCheckBox("Volunteer Work");
	
	chkbox2.setBounds(50,520,300,30);
	

	submit_btn=new JButton("Display");
	
	submit_btn.setBounds(180,560,120,40);
	
	submit_btn.setCursor(cur); 
	
	submit_btn.addActionListener(new ActionListener(){
	
	public void actionPerformed(ActionEvent event){
	
	submit_action(event);
	
	}
	
	});

	
	output_txtArea=new JTextArea();
	
	output_txtArea.setBounds(380,80,260,320);
	
	
	c.add(name_lbl);
	
	c.add(address_lbl);
	
	c.add(province_lbl);
	
	c.add(city_lbl);
	
	c.add(postal_lbl);
	
	c.add(major_lbl);
	
	c.add(compu);
	
	c.add(busine);
	
	c.add(cs);
	
	//c.add(busi);
	
	
	
	if(busine.isSelected()==true)
	
		c.add(busi);
	
	c.add(sub_lbl);
	
	
	
	c.add(phone_lbl);
	
	c.add(email_lbl);
	
	
	c.add(name_txt);
	
	c.add(name_txt);
	
	c.add(address_txt);
	
	c.add(province_txt);
	
	c.add(city_txt);
	
	c.add(postal_txt);
	
	c.add(phone_txt);
	
	c.add(email_txt);
	
	c.add(chkbox1);
	
	c.add(chkbox2);
	
	c.add(submit_btn);
	
	c.add(output_txtArea);
	
	}
	
	public static void submit_action(ActionEvent event){
	
		if(chkbox1.isSelected()==true&&chkbox2.isSelected()==false) {
		
			String name=name_txt.getText();
			
			String address=address_txt.getText();
			
			String province=province_txt.getText();
			
			String city=city_txt.getText();
			
			String postal=postal_txt.getText();
			
			String major="Computer Science";
			
			if(busine.isSelected()==true)
			
			major="Business";
			
			
			//String cssub=(String)cs.getSelectedItem();
			if(busine.isSelected()==true) {
			
				String busisub=(String)busi.getSelectedItem();
				
				String phone=phone_txt.getText();
				
				String email=email_txt.getText();
				
				output_txtArea.setText(" Name : " +name + "\n Address : " +address + "\n Province : " + province + 
				
				"\n City : "+city +" \n Phone no : "+phone +
				
				"\n Email : "+email + "\n Major: "+major+"\n Course : " + busisub +"\n Student Council");
			}else {
				
				
				String cssub=(String)cs.getSelectedItem();
				String phone=phone_txt.getText();
			
				String email=email_txt.getText();
			
				output_txtArea.setText(" Name : " +name + "\n Address : " +address + "\n Province : " + province + 
			
				"\n City : "+city +" \n Phone no : "+phone +
			
				"\n Email : "+email + "\n Major: "+major+"\n Course : " + cssub  +"\n Student Council");
			}
		
		
		}
		
		else if(chkbox2.isSelected()==true&&chkbox1.isSelected()==false){
			
			String name=name_txt.getText();
		
			String address=address_txt.getText();
		
			String province=province_txt.getText();
		
			String city=city_txt.getText();
		
			String postal=postal_txt.getText();
		
			String major="Computer Science";
		
			if(busine.isSelected()==true)
		
			major="Business";
		
		
			String cssub=(String)cs.getSelectedItem();
			if(busine.isSelected()==true) {
			String busisub=(String)busi.getSelectedItem();}
		
			String phone=phone_txt.getText();
		
			String email=email_txt.getText();
		
		
			output_txtArea.setText(" Name : " +name + "\n Address : " +address + "\n Province : " + province + 
		
			"\n City : "+city +" \n Phone no : "+phone +
		
			"\n Email : "+email + "\n Major: "+major+"\n Course : " + cssub+"\n Volunteer");
		
		
		
		}else if((chkbox1.isSelected()==true)||(chkbox2.isSelected()==true)) {
			String name=name_txt.getText();
		
			String address=address_txt.getText();
		
			String province=province_txt.getText();
		
			String city=city_txt.getText();
		
			String postal=postal_txt.getText();
		
			String major="Computer Science";
		
			if(busine.isSelected()==true)
		
			major="Business";
		
			String cssub=(String)cs.getSelectedItem();
			if(busine.isSelected()==true) {
			String busisub=(String)busi.getSelectedItem();}
		
			String phone=phone_txt.getText();
		
			String email=email_txt.getText();
		
			output_txtArea.setText(" Name : " +name + "\n Address : " +address + "\n Province : " + province + 
		
			"\n City : "+city +" \n Phone no : "+phone +
		
			"\n Email : "+email +  "\n Major: "+major+"\n Course : " + cssub+"\n Student Council and Volunteer");
		}else {
			String name=name_txt.getText();
		
			String address=address_txt.getText();
		
			String province=province_txt.getText();
		
			String city=city_txt.getText();
		
			String postal=postal_txt.getText();
		
			String major="Computer Science";
		
			if(busine.isSelected()==true)
		
			major="Business";
		
			String busisub=(String)busi.getSelectedItem();
		
		
			String phone=phone_txt.getText();
		
			String email=email_txt.getText();
		
			output_txtArea.setText(" Name : " +name + "\n Address : " +address + "\n Province : " + province + 
		
			"\n City : "+city +" \n Phone no : "+phone +
		
			"\n Email : "+email + "\n Major: "+major+"\n Course : " + busisub);
		}
	
	}

}

